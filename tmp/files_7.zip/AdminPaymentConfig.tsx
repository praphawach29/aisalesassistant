import { useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import {
  CreditCard, QrCode, Save, Eye, EyeOff,
  CheckCircle2, AlertCircle, Loader2, ExternalLink, Info
} from 'lucide-react';

// ── PromptPay QR Helper ─────────────────────────────────────
function generatePromptPayPayload(phone: string, amount?: number): string {
  const cleanPhone = phone.replace(/\D/g, '');
  const formattedPhone = cleanPhone.startsWith('0')
    ? '66' + cleanPhone.slice(1)
    : cleanPhone;

  const aid = '0016A000000677010111';
  const mobile = `0013${formattedPhone.length.toString().padStart(2, '0')}${formattedPhone}`;
  const merchantInfo = `${(mobile.length).toString().padStart(2, '0')}${mobile}`;
  const merchantAccountInfo = `${merchantInfo.length.toString().padStart(2, '0')}${merchantInfo}`;

  let payload =
    '000201' +                        // Payload Format Indicator
    '010211' +                         // Point of Initiation: Dynamic
    `26${merchantAccountInfo.length.toString().padStart(2, '0')}${merchantAccountInfo}` +
    '5303764' +                        // Transaction Currency: THB
    '5802TH';                          // Country Code: TH

  if (amount && amount > 0) {
    const amountStr = amount.toFixed(2);
    payload += `54${amountStr.length.toString().padStart(2, '0')}${amountStr}`;
  }

  payload += '6304';

  // CRC16-CCITT checksum
  let crc = 0xFFFF;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
    }
  }
  const checksum = (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');

  return payload + checksum;
}

// ── Component ───────────────────────────────────────────────
export default function AdminPaymentConfig() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showKeys, setShowKeys] = useState(false);
  const [previewAmount, setPreviewAmount] = useState('100');

  // Omise settings
  const [omisePublicKey, setOmisePublicKey] = useState('');
  const [omiseSecretKey, setOmiseSecretKey] = useState('');
  const [omiseEnabled, setOmiseEnabled] = useState(false);

  // PromptPay settings
  const [promptpayPhone, setPromptpayPhone] = useState('');
  const [promptpayName, setPromptpayName] = useState('');
  const [promptpayEnabled, setPromptpayEnabled] = useState(false);
  const [qrPayload, setQrPayload] = useState('');

  // Bank Transfer settings
  const [bankEnabled, setBankEnabled] = useState(true);
  const [bankName, setBankName] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [bankAccountName, setBankAccountName] = useState('');

  useEffect(() => {
    if (!authLoading && !isAdmin) navigate('/admin');
  }, [isAdmin, authLoading, navigate]);

  useEffect(() => {
    loadSettings();
  }, []);

  useEffect(() => {
    if (promptpayPhone && promptpayEnabled) {
      try {
        const amount = parseFloat(previewAmount) || undefined;
        const payload = generatePromptPayPayload(promptpayPhone, amount);
        setQrPayload(payload);
      } catch { setQrPayload(''); }
    }
  }, [promptpayPhone, previewAmount, promptpayEnabled]);

  const loadSettings = async () => {
    try {
      const { data } = await supabase.functions.invoke('settings-crypto', {
        body: { action: 'load_and_decrypt' }
      });
      const settings = data?.settings || [];
      const get = (key: string) => settings.find((s: any) => s.key === key)?.value || '';

      setOmisePublicKey(get('OMISE_PUBLIC_KEY'));
      setOmiseSecretKey(get('OMISE_SECRET_KEY'));
      setOmiseEnabled(get('OMISE_ENABLED') === 'true');
      setPromptpayPhone(get('PROMPTPAY_PHONE'));
      setPromptpayName(get('PROMPTPAY_NAME'));
      setPromptpayEnabled(get('PROMPTPAY_ENABLED') === 'true');
      setBankEnabled(get('BANK_TRANSFER_ENABLED') !== 'false');
      setBankName(get('BANK_NAME'));
      setBankAccount(get('BANK_ACCOUNT'));
      setBankAccountName(get('BANK_ACCOUNT_NAME'));
    } catch (e) {
      toast({ title: 'ไม่สามารถโหลดการตั้งค่าได้', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    try {
      const settings = [
        { key: 'OMISE_PUBLIC_KEY',       value: omisePublicKey,              encrypt: true },
        { key: 'OMISE_SECRET_KEY',        value: omiseSecretKey,              encrypt: true },
        { key: 'OMISE_ENABLED',           value: String(omiseEnabled),        encrypt: false },
        { key: 'PROMPTPAY_PHONE',         value: promptpayPhone,              encrypt: false },
        { key: 'PROMPTPAY_NAME',          value: promptpayName,               encrypt: false },
        { key: 'PROMPTPAY_ENABLED',       value: String(promptpayEnabled),    encrypt: false },
        { key: 'BANK_TRANSFER_ENABLED',   value: String(bankEnabled),         encrypt: false },
        { key: 'BANK_NAME',               value: bankName,                    encrypt: false },
        { key: 'BANK_ACCOUNT',            value: bankAccount,                 encrypt: false },
        { key: 'BANK_ACCOUNT_NAME',       value: bankAccountName,             encrypt: false },
      ];

      const { error } = await supabase.functions.invoke('settings-crypto', {
        body: { action: 'save_settings', settings }
      });

      if (error) throw error;

      toast({ title: '✅ บันทึกการตั้งค่าการชำระเงินแล้ว' });
    } catch (e) {
      toast({ title: 'เกิดข้อผิดพลาด', description: String(e), variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">การชำระเงิน</h1>
            <p className="text-muted-foreground text-sm mt-1">
              ตั้งค่าช่องทางรับชำระเงินจากลูกค้า
            </p>
          </div>
          <Button onClick={saveSettings} disabled={isSaving}>
            {isSaving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            บันทึก
          </Button>
        </div>

        <Tabs defaultValue="promptpay">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="promptpay">
              <QrCode className="h-4 w-4 mr-2" /> PromptPay QR
            </TabsTrigger>
            <TabsTrigger value="bank">
              🏦 โอนธนาคาร
            </TabsTrigger>
            <TabsTrigger value="omise">
              <CreditCard className="h-4 w-4 mr-2" /> Omise (บัตรเครดิต)
            </TabsTrigger>
          </TabsList>

          {/* ── PromptPay ─────────────────────────────────── */}
          <TabsContent value="promptpay" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="h-5 w-5" /> PromptPay QR Code
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Label>เปิดใช้งาน</Label>
                    <Switch checked={promptpayEnabled} onCheckedChange={setPromptpayEnabled} />
                    <Badge variant={promptpayEnabled ? 'default' : 'secondary'}>
                      {promptpayEnabled ? 'เปิด' : 'ปิด'}
                    </Badge>
                  </div>
                </div>
                <CardDescription>
                  Bot จะสร้าง QR Code PromptPay ให้ลูกค้าสแกนชำระเงินอัตโนมัติ
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>เบอร์มือถือ PromptPay *</Label>
                    <Input
                      value={promptpayPhone}
                      onChange={e => setPromptpayPhone(e.target.value)}
                      placeholder="0812345678"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>ชื่อผู้รับเงิน</Label>
                    <Input
                      value={promptpayName}
                      onChange={e => setPromptpayName(e.target.value)}
                      placeholder="นายสมชาย ใจดี"
                    />
                  </div>
                </div>

                {/* QR Preview */}
                {promptpayEnabled && promptpayPhone && (
                  <Card className="bg-muted/50">
                    <CardHeader>
                      <CardTitle className="text-sm">ตัวอย่าง QR Code</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-6 items-start">
                        <div className="flex flex-col items-center gap-2">
                          {/* QR Code rendered via API */}
                          <img
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(qrPayload)}`}
                            alt="PromptPay QR"
                            className="rounded-lg border bg-white p-2"
                            width={180}
                            height={180}
                          />
                          <p className="text-xs text-muted-foreground">QR Code จริง</p>
                        </div>
                        <div className="flex-1 space-y-3">
                          <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">ทดสอบกับจำนวนเงิน</Label>
                            <div className="flex gap-2">
                              <Input
                                type="number"
                                value={previewAmount}
                                onChange={e => setPreviewAmount(e.target.value)}
                                placeholder="จำนวนเงิน (บาท)"
                                className="w-40"
                              />
                              <span className="text-sm self-center text-muted-foreground">บาท</span>
                            </div>
                          </div>
                          <div className="text-sm space-y-1">
                            <p className="font-medium">ข้อมูล PromptPay:</p>
                            <p className="text-muted-foreground">เบอร์: {promptpayPhone}</p>
                            {promptpayName && <p className="text-muted-foreground">ชื่อ: {promptpayName}</p>}
                            {previewAmount && <p className="text-muted-foreground">จำนวน: ฿{parseFloat(previewAmount).toLocaleString()}</p>}
                          </div>
                          <div className="bg-blue-50 dark:bg-blue-950 rounded-lg p-3">
                            <p className="text-xs text-blue-700 dark:text-blue-300 flex gap-1">
                              <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                              Bot จะส่ง QR Code นี้ให้ลูกค้าเมื่อยืนยันออเดอร์ ลูกค้าสแกนจ่ายได้เลย
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Bank Transfer ──────────────────────────────── */}
          <TabsContent value="bank" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>🏦 โอนผ่านธนาคาร</CardTitle>
                  <div className="flex items-center gap-2">
                    <Label>เปิดใช้งาน</Label>
                    <Switch checked={bankEnabled} onCheckedChange={setBankEnabled} />
                  </div>
                </div>
                <CardDescription>
                  Bot แสดงเลขบัญชีให้ลูกค้าโอนเงิน แล้วส่งสลิปยืนยัน
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>ธนาคาร *</Label>
                    <Input
                      value={bankName}
                      onChange={e => setBankName(e.target.value)}
                      placeholder="ธนาคารกสิกรไทย (KBank)"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>เลขบัญชี *</Label>
                    <Input
                      value={bankAccount}
                      onChange={e => setBankAccount(e.target.value)}
                      placeholder="xxx-x-xxxxx-x"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>ชื่อบัญชี *</Label>
                  <Input
                    value={bankAccountName}
                    onChange={e => setBankAccountName(e.target.value)}
                    placeholder="บริษัท ABC จำกัด"
                  />
                </div>
                {bankEnabled && bankName && bankAccount && (
                  <Card className="bg-muted/50">
                    <CardContent className="pt-4">
                      <p className="text-sm font-medium mb-2">ตัวอย่างข้อความที่ Bot จะส่ง:</p>
                      <div className="bg-background rounded-lg p-3 text-sm space-y-1 border">
                        <p>💳 ช่องทางชำระเงิน:</p>
                        <p>🏦 {bankName}</p>
                        <p>เลขบัญชี: {bankAccount}</p>
                        <p>ชื่อ: {bankAccountName}</p>
                        <p className="text-muted-foreground text-xs mt-2">
                          หลังโอนกรุณาส่งสลิปมาที่แชทนี้ครับ
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── Omise ─────────────────────────────────────── */}
          <TabsContent value="omise" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" /> Omise (บัตรเครดิต/เดบิต)
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Label>เปิดใช้งาน</Label>
                    <Switch checked={omiseEnabled} onCheckedChange={setOmiseEnabled} />
                    <Badge variant={omiseEnabled ? 'default' : 'secondary'}>
                      {omiseEnabled ? 'เปิด' : 'ปิด'}
                    </Badge>
                  </div>
                </div>
                <CardDescription>
                  ลูกค้าชำระด้วยบัตรเครดิต/เดบิตผ่าน Omise — ตัดเงินอัตโนมัติ
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-amber-50 dark:bg-amber-950 rounded-lg p-3 flex gap-2">
                  <Info className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-amber-700 dark:text-amber-300">
                    <p className="font-medium">ต้องสมัคร Omise ก่อน</p>
                    <p>ไปที่ omise.co → สมัคร → ผ่าน KYC → ได้ API Keys ภายใน 1-3 วัน</p>
                    <p>ค่าธรรมเนียม: <strong>3.65%</strong> ต่อรายการ</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" asChild>
                    <a href="https://omise.co" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" /> สมัคร Omise
                    </a>
                  </Button>
                  <Button variant="outline" size="sm" asChild>
                    <a href="https://dashboard.omise.co/test/api-keys" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3 mr-1" /> Dashboard Omise
                    </a>
                  </Button>
                </div>

                <Separator />

                <div className="flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowKeys(!showKeys)}
                  >
                    {showKeys ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
                    {showKeys ? 'ซ่อน Keys' : 'แสดง Keys'}
                  </Button>
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label>Public Key</Label>
                    <Input
                      type={showKeys ? 'text' : 'password'}
                      value={omisePublicKey}
                      onChange={e => setOmisePublicKey(e.target.value)}
                      placeholder="pkey_test_xxxxxxxxx"
                    />
                    <p className="text-xs text-muted-foreground">
                      ใช้ใน Frontend — เริ่มด้วย pkey_test_ (ทดสอบ) หรือ pkey_live_ (จริง)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Secret Key</Label>
                    <Input
                      type={showKeys ? 'text' : 'password'}
                      value={omiseSecretKey}
                      onChange={e => setOmiseSecretKey(e.target.value)}
                      placeholder="skey_test_xxxxxxxxx"
                    />
                    <p className="text-xs text-muted-foreground">
                      ใช้ใน Backend เท่านั้น — เก็บเป็นความลับ ห้ามโชว์ใน Frontend
                    </p>
                  </div>
                </div>

                {omiseEnabled && omisePublicKey && omiseSecretKey && (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    <span className="text-sm">Omise พร้อมใช้งาน</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={saveSettings} disabled={isSaving} size="lg">
            {isSaving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            บันทึกการตั้งค่าทั้งหมด
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
}
