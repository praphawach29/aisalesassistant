-- ═══════════════════════════════════════════════════════════
-- Migration: เพิ่ม RLS ที่ยังขาด + Multi-tenant (store_id)
-- ไฟล์นี้: supabase/migrations/[timestamp]_rls_multitenant.sql
-- ═══════════════════════════════════════════════════════════

-- ─── 1. สร้าง stores table (Multi-tenant หลัก) ─────────────
CREATE TABLE IF NOT EXISTS public.stores (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name        TEXT NOT NULL DEFAULT 'My Store',
  slug        TEXT UNIQUE,
  plan        TEXT NOT NULL DEFAULT 'starter',
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- แต่ละ user มีได้แค่ 1 store (อัปเกรดได้)
CREATE UNIQUE INDEX IF NOT EXISTS stores_owner_idx ON public.stores(owner_id);

ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;

-- Owner เห็น/แก้ store ของตัวเองเท่านั้น
CREATE POLICY "Owner manages own store" ON public.stores
  FOR ALL USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- ─── 2. Helper function — ดึง store_id ของ user ──────────
CREATE OR REPLACE FUNCTION public.get_my_store_id()
RETURNS UUID
LANGUAGE sql STABLE
SECURITY DEFINER
AS $$
  SELECT id FROM public.stores WHERE owner_id = auth.uid() LIMIT 1;
$$;

-- ─── 3. เพิ่ม store_id ใน Tables หลัก ────────────────────

-- Products
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- Orders
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- FAQs
ALTER TABLE public.faqs
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- chat_conversations
ALTER TABLE public.chat_conversations
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- settings
ALTER TABLE public.settings
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- notifications
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES public.stores(id) ON DELETE CASCADE;

-- ─── 4. RLS Policies สำหรับ Products ────────────────────────
DROP POLICY IF EXISTS "Admins can manage products" ON public.products;
DROP POLICY IF EXISTS "Anyone can view products" ON public.products;

-- เจ้าของร้านจัดการสินค้าของตัวเอง
CREATE POLICY "Store owner manages products" ON public.products
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

-- ลูกค้าดูสินค้าของร้านได้ (ผ่าน store_id ที่ส่งมา)
CREATE POLICY "Public can view active products" ON public.products
  FOR SELECT USING (is_active = true);

-- ─── 5. RLS Policies สำหรับ Orders ──────────────────────────
DROP POLICY IF EXISTS "Admins can manage orders" ON public.orders;

CREATE POLICY "Store owner manages orders" ON public.orders
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

-- Bot (service role) สร้าง order ได้
CREATE POLICY "Service role manages orders" ON public.orders
  FOR ALL USING (auth.role() = 'service_role');

-- ─── 6. RLS Policies สำหรับ Settings ────────────────────────
DROP POLICY IF EXISTS "Admins can manage settings" ON public.settings;

CREATE POLICY "Store owner manages settings" ON public.settings
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

CREATE POLICY "Service role manages settings" ON public.settings
  FOR ALL USING (auth.role() = 'service_role');

-- ─── 7. RLS Policies สำหรับ FAQs ────────────────────────────
DROP POLICY IF EXISTS "Admins can manage faqs" ON public.faqs;

CREATE POLICY "Store owner manages faqs" ON public.faqs
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

CREATE POLICY "Public can view active faqs" ON public.faqs
  FOR SELECT USING (is_active = true);

-- ─── 8. RLS สำหรับ chat_conversations ───────────────────────
DROP POLICY IF EXISTS "Admins can view conversations" ON public.chat_conversations;

CREATE POLICY "Store owner views conversations" ON public.chat_conversations
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

CREATE POLICY "Service role manages conversations" ON public.chat_conversations
  FOR ALL USING (auth.role() = 'service_role');

-- ─── 9. RLS สำหรับ notifications ────────────────────────────
ALTER TABLE IF EXISTS public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Store owner views notifications" ON public.notifications
  FOR ALL USING (store_id = public.get_my_store_id())
  WITH CHECK (store_id = public.get_my_store_id());

CREATE POLICY "Service role manages notifications" ON public.notifications
  FOR ALL USING (auth.role() = 'service_role');

-- ─── 10. Auto-create store เมื่อ user สมัคร ─────────────────
CREATE OR REPLACE FUNCTION public.handle_new_user_store()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- สร้าง store ให้ user ใหม่อัตโนมัติ
  INSERT INTO public.stores (owner_id, name, slug)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'store_name', 'My Store'),
    LOWER(REPLACE(COALESCE(NEW.raw_user_meta_data->>'store_name', 'store-' || substr(NEW.id::text, 1, 8)), ' ', '-'))
  )
  ON CONFLICT (owner_id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Trigger: สร้าง store เมื่อ profile ถูกสร้าง
DROP TRIGGER IF EXISTS on_profile_created_create_store ON public.profiles;
CREATE TRIGGER on_profile_created_create_store
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_store();

-- ─── 11. สร้าง store ให้ users เดิมที่มีอยู่แล้ว ──────────────
INSERT INTO public.stores (owner_id, name)
SELECT id, 'My Store'
FROM auth.users
WHERE id NOT IN (SELECT owner_id FROM public.stores)
ON CONFLICT DO NOTHING;

-- ─── 12. อัพเดท store_id ให้ records เดิม ────────────────────
-- (ใส่ให้ records เดิมทั้งหมดของ admin คนแรก)
UPDATE public.products SET store_id = (SELECT id FROM public.stores LIMIT 1) WHERE store_id IS NULL;
UPDATE public.orders SET store_id = (SELECT id FROM public.stores LIMIT 1) WHERE store_id IS NULL;
UPDATE public.faqs SET store_id = (SELECT id FROM public.stores LIMIT 1) WHERE store_id IS NULL;
UPDATE public.settings SET store_id = (SELECT id FROM public.stores LIMIT 1) WHERE store_id IS NULL;
UPDATE public.chat_conversations SET store_id = (SELECT id FROM public.stores LIMIT 1) WHERE store_id IS NULL;
