import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ENCRYPTION_KEY = Deno.env.get("ENCRYPTION_KEY") || "";

// ── Decrypt helper ──────────────────────────────────────────
async function getKey(): Promise<CryptoKey> {
  const keyData = new TextEncoder().encode(ENCRYPTION_KEY.padEnd(32, "0").slice(0, 32));
  return await crypto.subtle.importKey("raw", keyData, { name: "AES-GCM" }, false, ["decrypt"]);
}
async function decrypt(enc: string): Promise<string> {
  if (!enc) return "";
  try {
    const key = await getKey();
    const combined = Uint8Array.from(atob(enc), c => c.charCodeAt(0));
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: combined.slice(0, 12) },
      key,
      combined.slice(12)
    );
    return new TextDecoder().decode(decrypted);
  } catch { return enc; }
}

// ── LINE Rich Menu API ──────────────────────────────────────
interface RichMenuButton {
  label: string;
  message: string;
  icon: string;
}

function buildRichMenuBody(menuName: string, buttons: RichMenuButton[]) {
  const cols = 3;
  const rows = 2;
  const W = 2500;
  const H = 843;
  const btnW = Math.floor(W / cols);
  const btnH = Math.floor(H / rows);

  const areas = buttons.slice(0, 6).map((btn, i) => ({
    bounds: {
      x: (i % cols) * btnW,
      y: Math.floor(i / cols) * btnH,
      width: btnW,
      height: btnH,
    },
    action: {
      type: "message",
      label: btn.label.slice(0, 20),
      text: btn.message,
    },
  }));

  return {
    size: { width: W, height: H },
    selected: true,
    name: menuName,
    chatBarText: "เมนู",
    areas,
  };
}

// สร้างรูป Rich Menu อัตโนมัติด้วย Canvas-like HTML → PNG
// (ใช้วิธีง่ายสุด: สร้าง SVG แล้วแปลง)
function buildRichMenuSvg(buttons: RichMenuButton[]): string {
  const W = 2500;
  const H = 843;
  const cols = 3;
  const rows = 2;
  const btnW = W / cols;
  const btnH = H / rows;

  const colors = ["#1a1a2e", "#16213e", "#0f3460", "#533483", "#e94560", "#2d6a4f"];

  let rects = "";
  let texts = "";

  buttons.slice(0, 6).forEach((btn, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = col * btnW;
    const y = row * btnH;
    const cx = x + btnW / 2;
    const cy = y + btnH / 2;
    const color = colors[i % colors.length];

    rects += `<rect x="${x}" y="${y}" width="${btnW}" height="${btnH}" fill="${color}" stroke="#333" stroke-width="2"/>`;
    texts += `<text x="${cx}" y="${cy - 40}" font-size="120" text-anchor="middle" dominant-baseline="middle">${btn.icon}</text>`;
    texts += `<text x="${cx}" y="${cy + 80}" font-size="80" font-family="Arial" fill="white" text-anchor="middle" font-weight="bold">${btn.label}</text>`;
  });

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">${rects}${texts}</svg>`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get LINE token
    const { data: tokenData } = await supabase
      .from("settings")
      .select("value")
      .eq("key", "LINE_CHANNEL_ACCESS_TOKEN")
      .maybeSingle();

    if (!tokenData?.value) {
      return new Response(
        JSON.stringify({ error: "ไม่พบ LINE Channel Access Token กรุณาตั้งค่าในหน้า Integrations" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const lineToken = await decrypt(tokenData.value);
    const lineHeaders = {
      "Authorization": `Bearer ${lineToken}`,
      "Content-Type": "application/json",
    };

    const { action, menuName, buttons, richMenuId } = await req.json();

    // ── GET current rich menu ──────────────────────────────
    if (action === "get_current") {
      const res = await fetch("https://api.line.me/v2/bot/user/all/richmenu", {
        headers: lineHeaders,
      });
      const data = await res.json();
      return new Response(
        JSON.stringify({ richMenuId: data.richMenuId || null }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ── DELETE rich menu ────────────────────────────────────
    if (action === "delete" && richMenuId) {
      // Unlink from all users
      await fetch(`https://api.line.me/v2/bot/richmenu/bulk/unlink`, {
        method: "POST",
        headers: lineHeaders,
        body: JSON.stringify({ richMenuId }),
      });
      // Delete the menu
      await fetch(`https://api.line.me/v2/bot/richmenu/${richMenuId}`, {
        method: "DELETE",
        headers: lineHeaders,
      });
      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ── CREATE rich menu ────────────────────────────────────
    if (action === "create") {
      if (!buttons || buttons.length < 1) {
        return new Response(
          JSON.stringify({ error: "ต้องมีอย่างน้อย 1 ปุ่ม" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // 1. สร้าง Rich Menu object
      const menuBody = buildRichMenuBody(menuName || "เมนูหลัก", buttons);
      const createRes = await fetch("https://api.line.me/v2/bot/richmenu", {
        method: "POST",
        headers: lineHeaders,
        body: JSON.stringify(menuBody),
      });

      if (!createRes.ok) {
        const err = await createRes.json();
        throw new Error(`LINE API Error: ${JSON.stringify(err)}`);
      }

      const { richMenuId: newMenuId } = await createRes.json();
      console.log(`Rich Menu created: ${newMenuId}`);

      // 2. อัพโหลดรูป Rich Menu (SVG → PNG)
      const svg = buildRichMenuSvg(buttons);
      const svgBlob = new TextEncoder().encode(svg);

      const uploadRes = await fetch(
        `https://api-data.line.me/v2/bot/richmenu/${newMenuId}/content`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${lineToken}`,
            "Content-Type": "image/svg+xml",
          },
          body: svgBlob,
        }
      );

      if (!uploadRes.ok) {
        console.warn("SVG upload failed, trying PNG fallback...");
        // Fallback: ใช้รูป placeholder สีเขียว 2500x843
        const placeholderRes = await fetch(
          "https://via.placeholder.com/2500x843/06C755/FFFFFF?text=Rich+Menu",
        );
        const placeholder = await placeholderRes.arrayBuffer();
        await fetch(
          `https://api-data.line.me/v2/bot/richmenu/${newMenuId}/content`,
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${lineToken}`,
              "Content-Type": "image/png",
            },
            body: placeholder,
          }
        );
      }

      // 3. Set เป็น Default Rich Menu
      const setDefaultRes = await fetch(
        `https://api.line.me/v2/bot/user/all/richmenu/${newMenuId}`,
        { method: "POST", headers: lineHeaders }
      );

      if (!setDefaultRes.ok) {
        console.warn("Could not set as default rich menu");
      }

      // 4. บันทึก ID ใน settings
      await supabase.from("settings").upsert({
        key: "LINE_RICH_MENU_ID",
        value: newMenuId,
      }, { onConflict: "key" });

      return new Response(
        JSON.stringify({
          success: true,
          richMenuId: newMenuId,
          message: "สร้าง Rich Menu สำเร็จและตั้งเป็น Default แล้ว",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("manage-line-richmenu error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
