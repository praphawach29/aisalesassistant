import { useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, LayoutGrid, Trash2, Plus, RefreshCw, Info, ExternalLink, Check } from 'lucide-react';

// ── Types ───────────────────────────────────────────────────
interface RichMenuButton {
  label: string;
  message: string;
  icon: string;
}

// ── Preset templates ─────────────────────────────────────────
const MENU_PRESETS = [
  {
    name: 'ร้านค้าทั่วไป',
    buttons: [
      { label: 'สินค้า', message: 'ดูสินค้าทั้งหมด', icon: '🛒' },
      { label: 'โปรโมชั่น', message: 'โปรโมชั่นวันนี้มีอะไรบ้าง?', icon: '🎉' },
      { label: 'ติดตามออเดอร์', message: 'ติดตามสถานะออเดอร์', icon: '📦' },
      { label: 'ที่อยู่จัดส่ง', message: 'จัดการที่อยู่จัดส่ง', icon: '📍' },
      { label: 'ติดต่อเรา', message: 'ติดต่อเจ้าหน้าที่', icon: '📞' },
      { label: 'คำถามที่พบบ่อย', message: 'FAQ', icon: '❓' },
    ],
  },
  {
    name: 'คลินิก/สุขภาพ',
    buttons: [
      { label: 'นัดหมาย', message: 'อยากนัดหมายแพทย์', icon: '📅' },
      { label: 'บริการ', message: 'บริการทั้งหมดมีอะไรบ้าง?', icon: '🏥' },
      { label: 'ราคา', message: 'ราคาบริการ', icon: '💰' },
      { label: 'เส้นทาง', message: 'วิธีเดินทางมาคลินิก', icon: '🗺️' },
      { label: 'โทรหาเรา', message: 'ต้องการโทรติดต่อ', icon: '📞' },
      { label: 'คำถาม', message: 'คำถามที่พบบ่อย', icon: '❓' },
    ],
  },
  {
    name: 'ร้านอาหาร',
    buttons: [
      { label: 'เมนู', message: 'ดูเมนูทั้งหมด', icon: '🍜' },
      { label: 'จองโต๊ะ', message: 'อยากจองโต๊ะ', icon: '🪑' },
      { label: 'Delivery', message: 'สั่ง Delivery', icon: '🛵' },
      { label: 'โปรโมชั่น', message: 'โปรโมชั่นวันนี้', icon: '🎉' },
      { label: 'เวลาเปิด', message: 'เปิดกี่โมงถึงกี่โมง?', icon: '🕐' },
      { label: 'ติดต่อ', message: 'ติดต่อร้าน', icon: '📞' },
    ],
  },
];

export default function AdminRichMenu() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [currentMenuId, setCurrentMenuId] = useState<string | null>(null);
  const [buttons, setButtons] = useState<RichMenuButton[]>(MENU_PRESETS[0].buttons);
  const [menuName, setMenuName] = useState('เมนูหลัก');
  const [selectedPreset, setSelectedPreset] = useState(0);

  useEffect(() => {
    if (!authLoading && !isAdmin) navigate('/admin');
  }, [isAdmin, authLoading, navigate]);

  const applyPreset = (idx: number) => {
    setSelectedPreset(idx);
    setButtons([...MENU_PRESETS[idx].buttons]);
    toast({ title: `✅ ใช้ Template "${MENU_PRESETS[idx].name}"` });
  };

  const updateButton = (idx: number, field: keyof RichMenuButton, value: string) => {
    const updated = [...buttons];
    updated[idx] = { ...updated[idx], [field]: value };
    setButtons(updated);
  };

  const createRichMenu = async () => {
    setIsSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-line-richmenu', {
        body: {
          action: 'create',
          menuName,
          buttons,
        }
      });

      if (error) throw error;

      setCurrentMenuId(data.richMenuId);
      toast({
        title: '✅ สร้าง Rich Menu สำเร็จ!',
        description: `Rich Menu ID: ${data.richMenuId}`,
      });
    } catch (e: any) {
      toast({
        title: 'เกิดข้อผิดพลาด',
        description: e.message || 'ไม่สามารถสร้าง Rich Menu ได้',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const deleteRichMenu = async () => {
    if (!currentMenuId) return;
    if (!confirm('ต้องการลบ Rich Menu นี้?')) return;

    setIsLoading(true);
    try {
      const { error } = await supabase.functions.invoke('manage-line-richmenu', {
        body: { action: 'delete', richMenuId: currentMenuId }
      });
      if (error) throw error;
      setCurrentMenuId(null);
      toast({ title: '🗑️ ลบ Rich Menu แล้ว' });
    } catch (e: any) {
      toast({ title: 'เกิดข้อผิดพลาด', description: e.message, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const refreshStatus = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('manage-line-richmenu', {
        body: { action: 'get_current' }
      });
      if (error) throw error;
      setCurrentMenuId(data.richMenuId || null);
      toast({ title: data.richMenuId ? `📋 Rich Menu: ${data.richMenuId}` : 'ยังไม่มี Rich Menu' });
    } catch (e: any) {
      toast({ title: 'เกิดข้อผิดพลาด', description: e.message, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <LayoutGrid className="h-6 w-6" /> LINE Rich Menu
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              ปุ่ม Shortcut ที่แสดงใต้ Chat LINE ลูกค้ากดแทนพิมพ์ได้เลย
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={refreshStatus} disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            </Button>
            {currentMenuId && (
              <Button variant="destructive" onClick={deleteRichMenu} disabled={isLoading}>
                <Trash2 className="h-4 w-4 mr-2" /> ลบ Rich Menu
              </Button>
            )}
          </div>
        </div>

        {/* Status */}
        <Card className={currentMenuId ? 'border-green-500/50 bg-green-50/50 dark:bg-green-950/20' : ''}>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              {currentMenuId
                ? <><Check className="h-5 w-5 text-green-600" /><div><p className="font-medium text-green-700 dark:text-green-400">Rich Menu ใช้งานอยู่</p><p className="text-xs text-muted-foreground font-mono">{currentMenuId}</p></div></>
                : <><Info className="h-5 w-5 text-muted-foreground" /><p className="text-muted-foreground">ยังไม่มี Rich Menu — กด &quot;สร้าง Rich Menu&quot; เพื่อเพิ่ม</p></>
              }
            </div>
          </CardContent>
        </Card>

        {/* Info */}
        <Card className="bg-blue-50/50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-4">
            <div className="flex gap-2">
              <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                <p className="font-medium">Rich Menu คืออะไร?</p>
                <p>ปุ่มที่แสดงอยู่ด้านล่างของ Chat LINE ลูกค้ากดปุ่มแทนการพิมพ์ได้เลย</p>
                <p>รองรับ 6 ปุ่ม — แต่ละปุ่มส่งข้อความเข้า Bot เมื่อกด</p>
                <a href="https://developers.line.biz/en/docs/messaging-api/using-rich-menus/"
                   target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center gap-1 underline">
                  LINE Docs <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Presets */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">เลือก Template สำเร็จรูป</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 flex-wrap">
              {MENU_PRESETS.map((p, i) => (
                <Button
                  key={i}
                  variant={selectedPreset === i ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => applyPreset(i)}
                >
                  {p.name}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Menu Config */}
        <Card>
          <CardHeader>
            <CardTitle>ตั้งค่าปุ่ม Rich Menu</CardTitle>
            <CardDescription>แก้ไขข้อความและ Emoji แต่ละปุ่ม (รองรับ 6 ปุ่ม)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>ชื่อ Rich Menu (สำหรับอ้างอิง)</Label>
              <Input value={menuName} onChange={e => setMenuName(e.target.value)} placeholder="เมนูหลัก" />
            </div>

            {/* Preview */}
            <div className="border rounded-xl overflow-hidden">
              <div className="bg-[#06C755] text-white text-xs px-3 py-1">ตัวอย่าง Rich Menu</div>
              <div className="grid grid-cols-3 gap-0.5 bg-gray-200 dark:bg-gray-700 p-0.5">
                {buttons.map((btn, i) => (
                  <div key={i} className="bg-white dark:bg-gray-800 flex flex-col items-center justify-center py-3 gap-1">
                    <span className="text-2xl">{btn.icon}</span>
                    <span className="text-xs font-medium text-gray-700 dark:text-gray-300">{btn.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Button editors */}
            <div className="grid grid-cols-2 gap-3">
              {buttons.map((btn, i) => (
                <Card key={i} className="p-3">
                  <p className="text-xs font-medium text-muted-foreground mb-2">ปุ่มที่ {i + 1}</p>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        value={btn.icon}
                        onChange={e => updateButton(i, 'icon', e.target.value)}
                        placeholder="🛒"
                        className="w-14 text-center"
                      />
                      <Input
                        value={btn.label}
                        onChange={e => updateButton(i, 'label', e.target.value)}
                        placeholder="ชื่อปุ่ม"
                        className="flex-1"
                        maxLength={10}
                      />
                    </div>
                    <Input
                      value={btn.message}
                      onChange={e => updateButton(i, 'message', e.target.value)}
                      placeholder="ข้อความที่จะส่งเมื่อกด"
                      className="text-xs"
                    />
                  </div>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Create Button */}
        <Button
          onClick={createRichMenu}
          disabled={isSaving}
          className="w-full"
          size="lg"
        >
          {isSaving
            ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />กำลังสร้าง Rich Menu...</>
            : <><Plus className="h-4 w-4 mr-2" />{currentMenuId ? 'อัพเดท' : 'สร้าง'} Rich Menu</>
          }
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          * ต้องตั้งค่า LINE Channel Access Token ในหน้า Integrations ก่อน
        </p>
      </div>
    </AdminLayout>
  );
}
